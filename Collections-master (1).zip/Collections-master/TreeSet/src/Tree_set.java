import java.util.*;
public class Tree_set {

	public static void main(String[] args) {
		 
		TreeSet<String> ts1 = new TreeSet<String>(); 
		  
        
        ts1.add("A"); 
        ts1.add("B"); 
        ts1.add("C");
        ts1.add("C"); 
       System.out.println(ts1); 


	}

}
