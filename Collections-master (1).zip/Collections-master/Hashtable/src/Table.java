import java.util.*; 
public class Table {
	public static void main(String[] args) {
		        Hashtable<Integer, String>  hm = new Hashtable<Integer, String>(); 
		  
		        hm.put(1, "Geeks"); 
		        hm.put(12, "forGeeks"); 
		        hm.put(15, "A computer"); 
		        hm.put(3, "Portal"); 
		  
		        System.out.println(hm); 
		    } 
		} 
	


